def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def mul(a, b):
    return a * b

def div(a, b):
    return a // b

# 니가 나를 모르는데 난들 너를 알겠느냐


